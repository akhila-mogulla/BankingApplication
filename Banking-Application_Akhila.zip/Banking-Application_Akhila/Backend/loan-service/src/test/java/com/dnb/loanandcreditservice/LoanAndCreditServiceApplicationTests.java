package com.dnb.loanandcreditservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanAndCreditServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
