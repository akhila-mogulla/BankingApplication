package com.dnb.loanandcreditservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.dnb.loanandcreditservice.dto.LoanAndCredit;
import com.dnb.loanandcreditservice.exceptions.IdNotFoundException;
import com.dnb.loanandcreditservice.mapper.EntityToResponseMapper;
import com.dnb.loanandcreditservice.mapper.RequestToEntityMapper;
import com.dnb.loanandcreditservice.request.LoanAndCreditRequest;
import com.dnb.loanandcreditservice.response.LoanAndCreditResponse;
import com.dnb.loanandcreditservice.service.LoanAndCreditService;

import jakarta.validation.Valid;

@RestController
@RefreshScope
@RequestMapping("api/loan")
public class LoanAndCreditController {
	
	@Autowired
	RequestToEntityMapper requestToEntityMapper;
	
	@Autowired
	EntityToResponseMapper entityToResponseMapper;
	
	@Autowired
	LoanAndCreditService loanAndCreditService;
	
	
	@PostMapping("/create")
	public ResponseEntity<?> createAccount(@Valid @RequestBody LoanAndCreditRequest loanAndCreditRequest) throws IdNotFoundException {
		LoanAndCredit lnc2 = requestToEntityMapper.getAccountEntityObject(loanAndCreditRequest);
		LoanAndCredit lnc3 = loanAndCreditService.createService(lnc2);
		LoanAndCreditResponse response = entityToResponseMapper.getAccountResponse(lnc3);
		return new ResponseEntity(response, HttpStatus.CREATED);

	}
	
	@GetMapping("/get/{accountId}")

	public ResponseEntity<?> getAccountById(@PathVariable("accountId") String accountId) throws IdNotFoundException {
		Optional<LoanAndCredit> optional = loanAndCreditService.getLoanAndCreditByAccountId(accountId);
		if (optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		} else {

			throw new IdNotFoundException("Enter the available account id");
		}
	}
	
	
	@GetMapping("/allCredit")
	public ResponseEntity<?> getAllloans() {
		Iterable<LoanAndCredit> optional = loanAndCreditService.getAllCredit();
		return ResponseEntity.ok(optional);
	}

}
