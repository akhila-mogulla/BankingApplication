package com.dnb.loanandcreditservice.dto;

public enum EAccountType {
	SAVINGS, CURRENT, FIXED_DEPOSIT

}
