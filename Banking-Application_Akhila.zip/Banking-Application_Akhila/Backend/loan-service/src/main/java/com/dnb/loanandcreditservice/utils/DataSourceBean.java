package com.dnb.loanandcreditservice.utils;

public class DataSourceBean {
	
	public String getData() {
		return "Hi from datasource bean";
	}

}
