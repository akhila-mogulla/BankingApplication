package com.dnb.loanandcreditservice.response;

import com.dnb.loanandcreditservice.dto.Type;

import lombok.Data;

@Data
public class LoanAndCreditResponse {
	
	String id;
	private Type[] applyType ;
	private long limit;
	boolean approvalstatus;
	private String accountId;

}
