package com.dnb.loanandcreditservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnb.loanandcreditservice.dto.LoanAndCredit;
import com.dnb.loanandcreditservice.exceptions.IdNotFoundException;
import com.dnb.loanandcreditservice.repo.LoanAndCreditRepository;

@Service
public class LoanAndCreditServiceImpl implements LoanAndCreditService {

	@Autowired
	LoanAndCreditRepository loanAndCreditRepository;

	@Override
	public LoanAndCredit createService(LoanAndCredit loanAndCredit) throws IdNotFoundException {
		// TODO Auto-generated method stub
		return loanAndCreditRepository.save(loanAndCredit);
	}

	@Override
	public Optional<LoanAndCredit> getLoanAndCreditByAccountId(String accountId) throws IdNotFoundException {
		// TODO Auto-generated method stub
		return loanAndCreditRepository.findById(accountId);
	}

	@Override
	public Iterable<LoanAndCredit> getAllCredit() {
		// TODO Auto-generated method stub
		return loanAndCreditRepository.findAll();
	}

	@Override
	public Optional<LoanAndCredit> getCreditById(String loanId) {
		// TODO Auto-generated method stub
		return loanAndCreditRepository.findById(loanId);
	}

	@Override
	public LoanAndCredit changeCreditStatuts(String loanId) throws IdNotFoundException {
		// TODO Auto-generated method stub
		boolean bool = loanAndCreditRepository.existsById(loanId);
		if (!bool)
			throw new IdNotFoundException("loan Id Not Found");
		Optional<LoanAndCredit> optional = this.getCreditById(loanId);
		if (optional.isEmpty())
			throw new IdNotFoundException("loan Id not found");

		LoanAndCredit credit2 = optional.get();
		if (!credit2.isApprovalstatus())
			credit2.setApprovalstatus(true);
		return loanAndCreditRepository.save(credit2);
	}

}
