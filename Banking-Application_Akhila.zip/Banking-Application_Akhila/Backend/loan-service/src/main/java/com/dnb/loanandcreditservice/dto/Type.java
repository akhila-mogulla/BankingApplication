package com.dnb.loanandcreditservice.dto;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;


//@Data
public class Type extends IdBasedEntity implements Serializable {
	
	@Enumerated(EnumType.STRING)
    @Column(length = 20, unique = true)
    private EType applyType;

	public EType getApplyType() {
		return applyType;
	}

	public void setApplyType(EType applyType) {
		this.applyType = applyType;
	}
	
	

}
