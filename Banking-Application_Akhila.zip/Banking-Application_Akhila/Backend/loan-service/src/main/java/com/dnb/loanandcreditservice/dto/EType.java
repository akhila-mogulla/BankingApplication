package com.dnb.loanandcreditservice.dto;

public enum EType {
	
	LOAN,
	CREDIT;

}
