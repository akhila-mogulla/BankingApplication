package com.dnb.loanandcreditservice.dto;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@EqualsAndHashCode
@NoArgsConstructor
@Data
public class Account {

	private String accountId;
	private EAccountType[] accountType;
	private long balance;
	private String contactNumber;
	private String panNumber;
	private String aadharNumber;
	private boolean accountStatus;
	private int userId;
	
	



}
