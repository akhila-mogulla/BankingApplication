package com.dnb.loanandcreditservice.service;

import java.util.List;
import java.util.Optional;


import com.dnb.loanandcreditservice.dto.LoanAndCredit;
import com.dnb.loanandcreditservice.exceptions.IdNotFoundException;



public interface LoanAndCreditService {
	
	
	public LoanAndCredit createService(LoanAndCredit loanAndCredit) throws IdNotFoundException;
	
	public Optional<LoanAndCredit> getLoanAndCreditByAccountId(String accountId) throws IdNotFoundException;
	
	public Iterable<LoanAndCredit> getAllCredit();

	public Optional<LoanAndCredit> getCreditById(String loanId);
	public LoanAndCredit changeCreditStatuts(String loanId) throws IdNotFoundException;

}
