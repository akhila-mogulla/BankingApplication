package com.dnb.loanandcreditservice.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnb.loanandcreditservice.dto.LoanAndCredit;
import com.dnb.loanandcreditservice.response.LoanAndCreditResponse;

@Component
public class EntityToResponseMapper {
	
	@Autowired
	RequestToEntityMapper requestToEntityMapper;
	
	
	public LoanAndCreditResponse getAccountResponse (LoanAndCredit loanAndCredit ) {
		
		LoanAndCreditResponse loanAndCreditResponse = new LoanAndCreditResponse();
		
		loanAndCreditResponse.setId(loanAndCredit.getId());
		loanAndCreditResponse.setApplyType(loanAndCredit.getApplyType());
		loanAndCreditResponse.setApprovalstatus(loanAndCredit.isApprovalstatus());
		loanAndCreditResponse.setLimit(loanAndCredit.getLimit());
		loanAndCreditResponse.setAccountId(loanAndCredit.getAccountId());
		
		return loanAndCreditResponse;
		
	}

}
