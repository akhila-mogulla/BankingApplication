package com.dnb.loanandcreditservice.request;



import com.dnb.loanandcreditservice.dto.Type;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class LoanAndCreditRequest {
	
	@Enumerated(EnumType.STRING)
	private Type[] applyType;
	private String accountId;

}
