package com.dnb.loanandcreditservice.dto;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
