package com.dnb.loanandcreditservice.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.loanandcreditservice.dto.LoanAndCredit;


@Repository
public interface LoanAndCreditRepository extends CrudRepository<LoanAndCredit, String> {
	
	List<LoanAndCredit> findAllByAccountId(String accountId);
}
