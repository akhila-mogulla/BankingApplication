package com.dnb.loanandcreditservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.loanandcreditservice.dto.LoanAndCredit;
import com.dnb.loanandcreditservice.request.LoanAndCreditRequest;



@Component
public class RequestToEntityMapper {

	public LoanAndCredit getAccountEntityObject(LoanAndCreditRequest request) {
		LoanAndCredit loanAndCredit = new LoanAndCredit();
		loanAndCredit.setAccountId(request.getAccountId());
		loanAndCredit.setApplyType(request.getApplyType());
		
		return loanAndCredit;
	}

}
