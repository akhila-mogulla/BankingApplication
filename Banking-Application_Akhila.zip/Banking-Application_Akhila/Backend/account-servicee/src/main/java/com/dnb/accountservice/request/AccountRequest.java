package com.dnb.accountservice.request;


import java.util.List;

import org.hibernate.validator.constraints.Length;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AccountRequest {
	

	@NotBlank(message = "Account type must be provided.")
	@Enumerated(EnumType.STRING)
	private List<String> accountType;
	//private EAccountType accountType;
	@Min(value = 10000, message="value should not be negative")
	private long balance;
	@Length(min = 10,max=10)
	@NotBlank(message = "Contact number should not be empty")
	@jakarta.validation.constraints.Pattern(regexp = "^[0-9]{10}$")
	private String contactNumber;
	@NotBlank(message = "panNumber should not be empty")
	private String panNumber;
	private String aadharNumber;
	@NotNull
	private int userId;
}

