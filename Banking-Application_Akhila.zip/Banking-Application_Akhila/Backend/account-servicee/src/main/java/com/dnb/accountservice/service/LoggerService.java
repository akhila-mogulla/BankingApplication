package com.dnb.accountservice.service;

import java.util.Optional;

import com.dnb.accountservice.dto.Logger;

public interface LoggerService {
	
	public void addLog(Logger logger); 

	public Optional<Logger> showLog(String accountId);

	public void deleteLog(String accountId);

}
