package com.dnb.accountservice.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.EAccountType;
import com.dnb.accountservice.response.AccountResponse;

@Component
public class EntityToResponseMapper {
	
	@Autowired
	RequestToEntityMapper requestToEntityMapper;
	
	
	public AccountResponse getAccountResponse (Account account ) {
		
		AccountResponse accountResponse = new AccountResponse();
		
		accountResponse.setAccountId(account.getAccountId());
		accountResponse.setAccountStatus(true);
		accountResponse.setAadharNumber(account.getAadharNumber());
		accountResponse.setAccountType(account.getAccountType());
		accountResponse.setBalance(account.getBalance());
		accountResponse.setContactNumber(account.getContactNumber());
		accountResponse.setPanNumber(account.getPanNumber());
		accountResponse.setUserId(account.getUserId());
		
		return accountResponse;
		
	}

}
