package com.dnb.accountservice.response;

import java.util.List;

import com.dnb.accountservice.dto.EAccountType;

import lombok.Data;


@Data
public class AccountResponse {
	
	
	private String accountId;
	private List<String> accountType;
	//private EAccountType accountType;
	private long balance;
	private String contactNumber;
	private String panNumber;
	private String aadharNumber;
	private boolean accountStatus;
	private int UserId;

}
