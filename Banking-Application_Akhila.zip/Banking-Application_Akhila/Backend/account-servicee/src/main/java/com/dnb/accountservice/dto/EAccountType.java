package com.dnb.accountservice.dto;

public enum EAccountType {
	SAVINGS,
	CURRENT,
	FIXED_DEPOSIT;

}
