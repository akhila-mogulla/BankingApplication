package com.dnb.accountservice.dto;

import java.util.List;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.accountservice.utils.CustomAccountIdGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@EqualsAndHashCode
@NoArgsConstructor
@ToString
@Entity
@Table()
@Data
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_seq")
	@GenericGenerator(name = "account_seq", strategy = "com.dnb.accountservice.utils.CustomAccountIdGenerator", parameters = {
			@Parameter(name = CustomAccountIdGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name = CustomAccountIdGenerator.VALUE_PREFIX_PARAMETER, value = "Acc_"),
			@Parameter(name = CustomAccountIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })

	private String accountId;
	//@Enumerated(EnumType.STRING)
	//private EAccountType accountType;
	private List<String> accountType;
	private long balance;
	@Column(nullable = false)
	private String contactNumber;
	@Column(unique = true, nullable = false)
	private String panNumber;
	@Column(unique = true, nullable = false)
	private String aadharNumber;
	private boolean accountStatus;
	@Column(nullable = false)
	private int userId;
	
	



}
