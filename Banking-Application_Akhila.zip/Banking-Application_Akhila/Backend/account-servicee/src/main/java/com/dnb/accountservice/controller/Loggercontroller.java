package com.dnb.accountservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.accountservice.dto.Logger;
import com.dnb.accountservice.service.LoggerService;

@RestController
public class Loggercontroller {
	
	@Autowired
	private LoggerService loggerService;

	// addLog
	public void addLog(Logger logger) {
		loggerService.addLog(logger);
	}

	// showLog
	@GetMapping("/account/{acctID}/logs")
	public Optional<Logger> showLog(@PathVariable String accountId) {
		return loggerService.showLog(accountId);
	}

	public void deleteLog(String accountId) {
		loggerService.deleteLog(accountId);
	}

}
