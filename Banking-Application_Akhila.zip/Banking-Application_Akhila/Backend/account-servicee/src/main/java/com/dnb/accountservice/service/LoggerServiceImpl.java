package com.dnb.accountservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnb.accountservice.dto.Logger;
import com.dnb.accountservice.repo.LoggerRepository;


@Service
public class LoggerServiceImpl implements LoggerService {
	
	@Autowired
	LoggerRepository loggerRepository;

	@Override
	public void addLog(Logger logger) {
		// TODO Auto-generated method stub
		loggerRepository.save(logger);

	}

	@Override
	public Optional<Logger> showLog(String accountId) {
		// TODO Auto-generated method stub
		return loggerRepository.findById(accountId);
	}

	@Override
	public void deleteLog(String accountId) {
		// TODO Auto-generated method stub
		loggerRepository.deleteById(accountId);

	}

}
