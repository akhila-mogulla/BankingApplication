package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.User;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.repo.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	RestTemplate restTemplate;

	@Value("${api.auth}")
	private String URL;

	@Override
	public Account createAccount(Account account) throws IdNotFoundException {
		// TODO Auto-generated method stub
		ResponseEntity<User> responseEntity = restTemplate.getForEntity(URL + "/" + account.getUserId(),
				User.class);
		account.setUserId(account.getUserId());
		return accountRepository.save(account);
	}

	@Override
	public Optional<Account> getAccountById(String accountId) {
		// TODO Auto-generated method stub
		return accountRepository.findById(accountId);
	}

	@Override
	public boolean deleteAccountById(String accountId) throws IdNotFoundException {
		// TODO Auto-generated method stub
		if (accountRepository.existsById(accountId)) {
			accountRepository.deleteById(accountId);
			return true;
		}

		else
			throw new IdNotFoundException("We cannot find any id to delete...");
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return (List<Account>) accountRepository.findAll();

	}

	@Override
	public long getBalance(String accountId) {
		// TODO Auto-generated method stub
		return accountRepository.findBalanceByAccountId(accountId);
	}

	@Override
	public void depositAmount(String accountId, long amount) {
		// TODO Auto-generated method stub
		accountRepository.saveBalanceByAccountId(accountId, amount);
		
	}

	@Override
	public void withdrawAmount(String accountId, long amount) {
		// TODO Auto-generated method stub
		accountRepository.withdrawAmountByAccountId(accountId, amount);
		
	}

	@Override
	public void transferAmount(String accountId, String destinationAccountId, long amount) {
		// TODO Auto-generated method stub
		accountRepository.withdrawAmountByAccountId(accountId, amount);
		accountRepository.saveBalanceByAccountId(destinationAccountId, amount);
		
	}



}
