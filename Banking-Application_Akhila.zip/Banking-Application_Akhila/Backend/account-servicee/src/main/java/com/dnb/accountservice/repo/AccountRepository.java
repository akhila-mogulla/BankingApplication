package com.dnb.accountservice.repo;





import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.accountservice.dto.Account;

import jakarta.transaction.Transactional;


@Repository
public interface AccountRepository extends CrudRepository<Account, String>{
	
	@Query("select balance from Account where accountId = ?1")
	public long findBalanceByAccountId(String accountId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Account set balance = balance+?2 where accountId=?1")
	public void saveBalanceByAccountId(String accountId, long amount);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Account set balance = balance-?2 where accountId=?1")
	public void withdrawAmountByAccountId(String accountId, long amount);

}