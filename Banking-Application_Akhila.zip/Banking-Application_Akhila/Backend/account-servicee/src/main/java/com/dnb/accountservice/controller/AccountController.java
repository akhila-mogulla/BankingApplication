package com.dnb.accountservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Logger;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.mapper.EntityToResponseMapper;
import com.dnb.accountservice.mapper.RequestToEntityMapper;
import com.dnb.accountservice.request.AccountRequest;
import com.dnb.accountservice.response.AccountResponse;
import com.dnb.accountservice.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RefreshScope
@RequestMapping("api/account")
public class AccountController {

	@Autowired
	RequestToEntityMapper mapper;

	@Autowired
	AccountService accountService;

	@Autowired
	Loggercontroller loggercontroller;

	@Autowired
	EntityToResponseMapper entityToResponseMapper;

	@PostMapping("/create")
	public ResponseEntity<?> createAccount(@Valid @RequestBody AccountRequest account) throws IdNotFoundException {
		Account account2 = mapper.getAccountEntityObject(account);
		Account account3 = accountService.createAccount(account2);
		AccountResponse response = entityToResponseMapper.getAccountResponse(account3);
		return new ResponseEntity(response, HttpStatus.CREATED);

	}

	@DeleteMapping("/delete/{accountId}")
	public ResponseEntity<?> deleteAccountById(@PathVariable("accountId") String accoutId) throws IdNotFoundException {
		boolean account = accountService.deleteAccountById(accoutId);
		if (account) {
			return ResponseEntity.noContent().build();

		} else
			throw new IdNotFoundException("account id not available to delete");
	}

	@GetMapping("/get/{accountId}")

	public ResponseEntity<?> getAccountById(@PathVariable("accountId") String accountId) throws IdNotFoundException {
		Optional<Account> optional = accountService.getAccountById(accountId);
		if (optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		} else {

			throw new IdNotFoundException("Enter the available account id");
		}
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAllAccounts(/* @PathVariable("accountId") String accountId */)
			throws IdNotFoundException {
		List<Account> optional = accountService.getAllAccounts();
		return ResponseEntity.ok(optional);
	}

	@GetMapping("/balanceByaccId/{accountId}")
	public long getBalanceByAccountId(@PathVariable("accountId") String accountId) throws IdNotFoundException {
		return accountService.getBalance(accountId);

	}

	// depositAmount
	@PutMapping("/{accountId}/deposit/{amount}")
	public void depositAmount(@PathVariable String accountId, @PathVariable long amount) throws IdNotFoundException {
		long initBal = getBalanceByAccountId(accountId);
		accountService.depositAmount(accountId, amount);
		Logger logger = new Logger(accountId, "Deposited", "Success", initBal, initBal + amount);
		loggercontroller.addLog(logger);
	}

	// withdrawAmount
	@PutMapping("/{accountId}/withdraw/{amount}")
	public void withdrawAmount(@PathVariable String accountId, @PathVariable long amount) throws IdNotFoundException {
		long initBal = getBalanceByAccountId(accountId);
		accountService.withdrawAmount(accountId, amount);
		Logger logger = new Logger(accountId, "Withdrawn", "Success", initBal, initBal - amount);
		loggercontroller.addLog(logger);
	}

	// transferAmount
	@PutMapping("/{accountId}/transfer/{destinationAccountId}/{amount}")
	public void transferAmount(@PathVariable String accountId, @PathVariable String destinationAccountId,
			@PathVariable long amount) throws IdNotFoundException {
		long initBalSender = getBalanceByAccountId(accountId);
		long initBalReceiver = getBalanceByAccountId(destinationAccountId);
		accountService.transferAmount(accountId, destinationAccountId, amount);
		Logger loggerSender = new Logger(accountId, "Transferred", "Success", initBalSender, initBalSender - amount);
		loggercontroller.addLog(loggerSender);
		Logger loggerReceiver = new Logger(destinationAccountId, "Received", "Success", initBalReceiver,
				initBalReceiver + amount);
		loggercontroller.addLog(loggerReceiver);
	}

}
