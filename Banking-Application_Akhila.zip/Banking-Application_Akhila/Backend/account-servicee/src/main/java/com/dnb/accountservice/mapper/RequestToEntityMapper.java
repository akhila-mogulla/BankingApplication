package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.EAccountType;
import com.dnb.accountservice.request.AccountRequest;

@Component
public class RequestToEntityMapper {

	public Account getAccountEntityObject(AccountRequest accountRequest) {
		Account account = new Account();
		account.setAccountType(accountRequest.getAccountType());
		account.setAadharNumber(accountRequest.getAadharNumber());
		account.setPanNumber(accountRequest.getPanNumber());
		account.setBalance(accountRequest.getBalance());
		account.setContactNumber(accountRequest.getContactNumber());
		account.setUserId(accountRequest.getUserId());
		return account;
	}

}
