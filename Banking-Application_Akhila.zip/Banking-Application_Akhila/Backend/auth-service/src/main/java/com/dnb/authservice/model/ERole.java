package com.dnb.authservice.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
