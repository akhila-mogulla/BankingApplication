export interface IAccount {
  accountType: string;
  panNumber: string;
  aadharNumber: string;
  contact: string;
  balance: number;
  customerId: number;
}
