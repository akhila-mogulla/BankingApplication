import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IAccount } from '../models/iaccount';
import { Observable } from 'rxjs';

const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root',
})
export class AccountService {
  constructor(private httpClient: HttpClient) {}

  endPoint: string = '/api/account';

  createAccount(account: IAccount): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/create',
      account,
      headerData
    );
  }

  depositAmount(accountId: string, amount: number): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/deposit/' + accountId,
      { amount: amount },
      headerData
    );
  }

  withdrawAmount(accountId: string, amount: number): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/withdraw' + accountId,
      { amount: amount },
      headerData
    );
  }

  getAccount(customerId: number): Observable<any> {
    return this.httpClient.get(this.endPoint + '/user/' + customerId);
  }

  closeAccount(accountId: string): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/close/' + accountId,
      {},
      headerData
    );
  }
}
