import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateAccountComponent } from './components/forms/create-account/create-account.component';
import { AccountDepositComponent } from './components/forms/account-deposit/account-deposit.component';
import { AccountWithdrawComponent } from './components/forms/account-withdraw/account-withdraw.component';

const routes: Routes = [
  { path: 'create-account', component: CreateAccountComponent },
  { path: 'account-deposit', component: AccountDepositComponent },
  { path: 'account-withdraw', component: AccountWithdrawComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AccountRoutingModule {}
