import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/account/services/account.service';
import { LoanService } from 'src/app/loan/services/loan.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  userDetails: any = {};
  accountDetails: any = {};
  loanDetails: any = [];
  flag: boolean = false;
  balance: string = '';

  constructor(
    private accountService: AccountService,
    private loanService: LoanService
  ) {}

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails') || '');
    // fetching account details by user id
    this.accountService.getAccount(this.userDetails.id).subscribe(
      (res) => {
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.accountDetails = res;
        // if account details fetched successfully, then fetching loans linked to this account
        this.loanService
          .getLoansByAccountId(this.accountDetails.accountId)
          .subscribe(
            (res) => {
              console.log(res);
              this.loanDetails = res;
            },
            (err) => {
              console.log(err);
            }
          );
      },
      (err) => {
        console.log(err.status);
        if (err.status == 404) {
          this.flag = true;
        }
      }
    );
  }

  showBalance() {
    if (this.balance == '' || this.balance == null || this.balance == undefined)
      this.balance = this.accountDetails.balance;
    else this.balance = '';
  }
}
