import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminDashboardRoutingModule } from './admin-dashboard-routing.module';
import { ApproveLoansComponent } from './components/forms/approve-loans/approve-loans.component';
import { CloseAccountComponent } from './components/forms/close-account/close-account.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LoanService } from 'src/app/loan/services/loan.service';
import { httpInterceptors } from 'src/app/shared/interceptors';
import { AccountService } from 'src/app/account/services/account.service';

@NgModule({
  declarations: [ApproveLoansComponent, CloseAccountComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    AdminDashboardRoutingModule,
  ],
  providers: [LoanService, AccountService, httpInterceptors],
})
export class AdminDashboardModule {}
