import { Injectable } from '@angular/core';
import { ILoan } from '../models/iloan';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root',
})
export class LoanService {
  constructor(private httpClient: HttpClient) {}

  endPoint: string = '/api/loan';

  createLoan(loan: ILoan): Observable<any> {
    return this.httpClient.post(this.endPoint + '/create', loan, headerData);
  }

  getLoansByAccountId(accountId: string): Observable<any> {
    console.log(this.endPoint + '/account/' + accountId);
    return this.httpClient.get(this.endPoint + '/account/' + accountId);
  }

  approveLoan(loanId: string): Observable<any> {
    return this.httpClient.put(
      this.endPoint + '/approve/' + loanId,
      {},
      headerData
    );
  }
}
